﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class cashierDashboard : Form
    {
        public cashierDashboard()
        {
            InitializeComponent();
            CashiercomboBox.Items.Clear();
            CashiercomboBox.Items.Add("Last three Order ");
            CashiercomboBox.Items.Add("Total Sales Made");
            CashiercomboBox.Items.Add("Top Item sold by the You");
        }
        private string cashierUsername;

        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");

        private void ExecuteQuery(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        
        private int cashierID = -1;

        public cashierDashboard(string username)
        {
            InitializeComponent();
            this.cashierUsername = username;
            // Retrieve the cashierID based on the provided username
            this.cashierID = GetCashierID(username);

            CashiercomboBox.Items.Clear();
            CashiercomboBox.Items.Add("Last three Order");
            CashiercomboBox.Items.Add("Total Sales Made");
            CashiercomboBox.Items.Add("Top Item sold by You");
            CashiercomboBox.SelectedIndexChanged += cashierCombobox_SelectedIndexChanged;
        }

       
        private int GetCashierID(string username)
        {
            int cashierID = -1; // Default value if not found
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT CashierID FROM Cashier WHERE cashierUsername = @Username";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            cashierID = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving cashierID: " + ex.Message);
            }
            return cashierID;
        }

        // Update your switch case accordingly
        private void cashierCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedOption = CashiercomboBox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedOption))
            {
                MessageBox.Show("Please select an option.");
                return;
            }

            switch (selectedOption)
            {
                case "Last three Order":
                    ExecuteQuery($"SELECT TOP 3 * FROM Orders WHERE cashierid = {cashierID} ORDER BY order_id DESC");
                    break;

                case "Total Sales Made":
                    ExecuteQuery($"SELECT cashierid, SUM(Total) AS TotalSales FROM Orders WHERE cashierid = {cashierID} GROUP BY cashierid");
                    break;

                case "Top Item sold by You":
                    ExecuteQuery($"SELECT TOP 1 oi.itemid, i.ItemName, COUNT(oi.itemid) AS ItemCount FROM OrderedItems oi " +
                                 $"JOIN Item i ON oi.itemid = i.ItemID WHERE oi.orderid IN (SELECT order_id FROM Orders WHERE cashierid = {cashierID}) " +
                                 $"GROUP BY oi.itemid, i.ItemName ORDER BY ItemCount DESC");
                    break;


                default:
                   
                break;
            }
        }

        private void Logoutbutton_Click(object sender, EventArgs e)
        {
            HomeScreen h=new HomeScreen();
            h.Visible = true;
            this.Visible = false;
        }
    }
}

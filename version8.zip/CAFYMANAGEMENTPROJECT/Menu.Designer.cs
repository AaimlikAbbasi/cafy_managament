﻿

namespace CAFYMANAGEMENTPROJECT
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenucomboBox = new System.Windows.Forms.ComboBox();
            this.Combolabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Orderbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MenucomboBox
            // 
            this.MenucomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MenucomboBox.FormattingEnabled = true;
            this.MenucomboBox.ItemHeight = 16;
            this.MenucomboBox.Items.AddRange(new object[] {
            "Breakfast",
            "Lunch",
            "Dinner"});
            this.MenucomboBox.Location = new System.Drawing.Point(12, 156);
            this.MenucomboBox.Name = "MenucomboBox";
            this.MenucomboBox.Size = new System.Drawing.Size(162, 24);
            this.MenucomboBox.TabIndex = 0;
            this.MenucomboBox.SelectedIndexChanged += new System.EventHandler(this.MenucomboBox_SelectedIndexChanged);
            // 
            // Combolabel
            // 
            this.Combolabel.AutoSize = true;
            this.Combolabel.Font = new System.Drawing.Font("Cooper Black", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Combolabel.ForeColor = System.Drawing.Color.BurlyWood;
            this.Combolabel.Location = new System.Drawing.Point(12, 116);
            this.Combolabel.Name = "Combolabel";
            this.Combolabel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Combolabel.Size = new System.Drawing.Size(163, 31);
            this.Combolabel.TabIndex = 1;
            this.Combolabel.Text = "Menu Type";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(254, 80);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(659, 297);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.BurlyWood;
            this.label1.Location = new System.Drawing.Point(17, 26);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(122, 44);
            this.label1.TabIndex = 3;
            this.label1.Text = "Menu";
            // 
            // Orderbutton
            // 
            this.Orderbutton.BackColor = System.Drawing.Color.BurlyWood;
            this.Orderbutton.Location = new System.Drawing.Point(947, 390);
            this.Orderbutton.Name = "Orderbutton";
            this.Orderbutton.Size = new System.Drawing.Size(106, 35);
            this.Orderbutton.TabIndex = 0;
            this.Orderbutton.Text = "Order";
            this.Orderbutton.UseVisualStyleBackColor = false;
            this.Orderbutton.Click += new System.EventHandler(this.Orderbutton_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1080, 452);
            this.Controls.Add(this.Orderbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Combolabel);
            this.Controls.Add(this.MenucomboBox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Menu";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox MenucomboBox;
        private System.Windows.Forms.Label Combolabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Orderbutton;
    }
}
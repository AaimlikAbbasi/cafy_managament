﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class placeorder : Form
    {
        private int customerId;  // New field to store customer ID

        public placeorder(int customerId)
        {
            InitializeComponent();
            this.customerId = customerId;  // Set customer ID from constructor
            PopulateComboBox();
        }
        //   private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafy_management;Integrated Security=True"); // Replace with your SQL Server connection string
       // private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        private List<string> selectedItems = new List<string>();
        private void PopulateComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT DISTINCT ItemCategory FROM Item";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader["ItemCategory"].ToString());
                        }
                    }
                }
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = comboBox1.SelectedItem.ToString();
            DisplayMenu(selectedCategory);
        }
        private void DisplayMenu(string category)
        {
            // Clear existing columns and rows in dataGridView2
            dataGridView2.Columns.Clear();
            dataGridView2.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT ItemID, ItemName, ItemPrice FROM Item WHERE ItemCategory = @Category";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Category", category);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Add columns to dataGridView2
                        dataGridView2.Columns.Add("ItemID", "Item ID");
                        dataGridView2.Columns.Add("ItemName", "Item Name");
                        dataGridView2.Columns.Add("ItemPrice", "Item Price");

                        while (reader.Read())
                        {
                            // Fetch details from the database
                            int itemID = Convert.ToInt32(reader["ItemID"]);
                            string itemName = reader["ItemName"].ToString();
                            int itemPrice = Convert.ToInt32(reader["ItemPrice"]);

                           
                            dataGridView2.Rows.Add(itemID, itemName, itemPrice);
                        }
                    }
                }
            }
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Calculate the total price from selected items
            decimal totalAmount = CalculateTotalPriceFromSelectedItems();

            // Create an instance of form10, passing the customer ID, total amount, and selected items
            paymethod form10 = new paymethod(customerId, totalAmount, selectedItems);
            form10.Show();
            this.Hide();
        }

        private decimal CalculateTotalPriceFromSelectedItems()
        {
            decimal totalPrice = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                foreach (string itemId in selectedItems)
                {
                    string query = "SELECT ItemPrice FROM Item WHERE ItemID = @ItemID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ItemID", itemId);

                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            int itemPrice = Convert.ToInt32(result);
                            totalPrice += itemPrice;
                        }
                    }
                }
            }

            return totalPrice;
        }


        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string itemName = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();

            if (!selectedItems.Contains(itemName))
            {
                selectedItems.Add(itemName);

                UpdateSelectedItems();
            }
        }

        private void UpdateSelectedItems()
        {
            dataGridView1.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                foreach (string itemId in selectedItems)
                {
                    string query = "SELECT ItemID, ItemName, ItemPrice FROM Item WHERE ItemID = @ItemID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ItemID", itemId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Fetch details from the database
                                int itemID = Convert.ToInt32(reader["ItemID"]);
                                string itemName = reader["ItemName"].ToString();
                                int itemPrice = Convert.ToInt32(reader["ItemPrice"]);

                                dataGridView1.Rows.Add(itemID, itemName, itemPrice);
                            }
                        }
                    }
                }

                
                CalculateTotalPrice();
            }
        }



        private void PLACE_ORDER_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CalculateTotalPrice();
        }
        private void CalculateTotalPrice()
        {
            decimal totalPrice = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["ItemPrice2"].Value != null)
                {
                    int itemPrice = Convert.ToInt32(row.Cells["ItemPrice2"].Value);
                    totalPrice += itemPrice;
                }
            }

            
            textBox2.Text = $"Total Price: {totalPrice:C}";
        }


        private void label3_Click(object sender, EventArgs e)
        {
           
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string enteredItemId = textBox1.Text.Trim();

            if (!string.IsNullOrEmpty(enteredItemId))
            {

                if (!selectedItems.Contains(enteredItemId))
                {
                    
                    selectedItems.Add(enteredItemId);

                    // Update dataGridView1
                    UpdateSelectedItems();
                }
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            string enteredId = textBox1.Text;

            if (!string.IsNullOrEmpty(enteredId))
            {
                UpdateOrderItemsById(enteredId);
            }
        }
        private void UpdateOrderItemsById(string itemId)
        {
            dataGridView1.Rows.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT ItemID, ItemName, ItemPrice FROM Item WHERE ItemID = @ItemID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ItemID", itemId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Fetch details from the database
                            int itemID = Convert.ToInt32(reader["ItemID"]);
                            string itemName = reader["ItemName"].ToString();
                            int itemPrice = Convert.ToInt32(reader["ItemPrice"]); // Corrected this line

                            // Add a new row to dataGridView1 with the fetched details
                            dataGridView1.Rows.Add(itemID, itemName, itemPrice);
                        }
                    }
                }
            }
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class ManagerFunction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddCustomerbutton = new System.Windows.Forms.Button();
            this.DeleteCustomerbutton = new System.Windows.Forms.Button();
            this.AddCashierbutton = new System.Windows.Forms.Button();
            this.DeleteCashierbutton = new System.Windows.Forms.Button();
            this.AddItembutton = new System.Windows.Forms.Button();
            this.DeleteItemButton = new System.Windows.Forms.Button();
            this.Logoutbutton = new System.Windows.Forms.Button();
            this.updateInventoryButton = new System.Windows.Forms.Button();
            this.ShowInventorybutton = new System.Windows.Forms.Button();
            this.updateItembutton = new System.Windows.Forms.Button();
            this.Reportbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddCustomerbutton
            // 
            this.AddCustomerbutton.Location = new System.Drawing.Point(155, 86);
            this.AddCustomerbutton.Name = "AddCustomerbutton";
            this.AddCustomerbutton.Size = new System.Drawing.Size(122, 48);
            this.AddCustomerbutton.TabIndex = 0;
            this.AddCustomerbutton.Text = "Add Customer";
            this.AddCustomerbutton.UseVisualStyleBackColor = true;
            this.AddCustomerbutton.Click += new System.EventHandler(this.AddCustomerbutton_Click);
            // 
            // DeleteCustomerbutton
            // 
            this.DeleteCustomerbutton.Location = new System.Drawing.Point(418, 86);
            this.DeleteCustomerbutton.Name = "DeleteCustomerbutton";
            this.DeleteCustomerbutton.Size = new System.Drawing.Size(122, 48);
            this.DeleteCustomerbutton.TabIndex = 1;
            this.DeleteCustomerbutton.Text = "Delete Customer";
            this.DeleteCustomerbutton.UseVisualStyleBackColor = true;
            this.DeleteCustomerbutton.Click += new System.EventHandler(this.DeleteCustomerbutton_Click);
            // 
            // AddCashierbutton
            // 
            this.AddCashierbutton.Location = new System.Drawing.Point(155, 156);
            this.AddCashierbutton.Name = "AddCashierbutton";
            this.AddCashierbutton.Size = new System.Drawing.Size(122, 48);
            this.AddCashierbutton.TabIndex = 2;
            this.AddCashierbutton.Text = "Add Cashier";
            this.AddCashierbutton.UseVisualStyleBackColor = true;
            this.AddCashierbutton.Click += new System.EventHandler(this.AddCashierbutton_Click);
            // 
            // DeleteCashierbutton
            // 
            this.DeleteCashierbutton.Location = new System.Drawing.Point(418, 156);
            this.DeleteCashierbutton.Name = "DeleteCashierbutton";
            this.DeleteCashierbutton.Size = new System.Drawing.Size(122, 48);
            this.DeleteCashierbutton.TabIndex = 3;
            this.DeleteCashierbutton.Text = "Delete Cashier";
            this.DeleteCashierbutton.UseVisualStyleBackColor = true;
            this.DeleteCashierbutton.Click += new System.EventHandler(this.DeleteCashierbutton_Click);
            // 
            // AddItembutton
            // 
            this.AddItembutton.Location = new System.Drawing.Point(155, 229);
            this.AddItembutton.Name = "AddItembutton";
            this.AddItembutton.Size = new System.Drawing.Size(122, 48);
            this.AddItembutton.TabIndex = 4;
            this.AddItembutton.Text = "Add Item";
            this.AddItembutton.UseVisualStyleBackColor = true;
            this.AddItembutton.Click += new System.EventHandler(this.AddItembutton_Click);
            // 
            // DeleteItemButton
            // 
            this.DeleteItemButton.Location = new System.Drawing.Point(418, 229);
            this.DeleteItemButton.Name = "DeleteItemButton";
            this.DeleteItemButton.Size = new System.Drawing.Size(122, 48);
            this.DeleteItemButton.TabIndex = 5;
            this.DeleteItemButton.Text = "Delete Item";
            this.DeleteItemButton.UseVisualStyleBackColor = true;
            this.DeleteItemButton.Click += new System.EventHandler(this.DeleteItemButton_Click);
            // 
            // Logoutbutton
            // 
            this.Logoutbutton.Location = new System.Drawing.Point(666, 389);
            this.Logoutbutton.Name = "Logoutbutton";
            this.Logoutbutton.Size = new System.Drawing.Size(106, 46);
            this.Logoutbutton.TabIndex = 6;
            this.Logoutbutton.Text = "Logout";
            this.Logoutbutton.UseVisualStyleBackColor = true;
            this.Logoutbutton.Click += new System.EventHandler(this.Logoutbutton_Click);
            // 
            // updateInventoryButton
            // 
            this.updateInventoryButton.Location = new System.Drawing.Point(155, 308);
            this.updateInventoryButton.Name = "updateInventoryButton";
            this.updateInventoryButton.Size = new System.Drawing.Size(122, 48);
            this.updateInventoryButton.TabIndex = 7;
            this.updateInventoryButton.Text = "Update Stock";
            this.updateInventoryButton.UseVisualStyleBackColor = true;
            this.updateInventoryButton.Click += new System.EventHandler(this.updateInventoryButton_Click);
            // 
            // ShowInventorybutton
            // 
            this.ShowInventorybutton.Location = new System.Drawing.Point(418, 308);
            this.ShowInventorybutton.Name = "ShowInventorybutton";
            this.ShowInventorybutton.Size = new System.Drawing.Size(122, 48);
            this.ShowInventorybutton.TabIndex = 8;
            this.ShowInventorybutton.Text = "Inventory";
            this.ShowInventorybutton.UseVisualStyleBackColor = true;
            this.ShowInventorybutton.Click += new System.EventHandler(this.ShowInventorybutton_Click);
            // 
            // updateItembutton
            // 
            this.updateItembutton.Location = new System.Drawing.Point(155, 387);
            this.updateItembutton.Name = "updateItembutton";
            this.updateItembutton.Size = new System.Drawing.Size(122, 48);
            this.updateItembutton.TabIndex = 9;
            this.updateItembutton.Text = "Update Item";
            this.updateItembutton.UseVisualStyleBackColor = true;
            this.updateItembutton.Click += new System.EventHandler(this.updateItembutton_Click);
            // 
            // Reportbutton
            // 
            this.Reportbutton.Location = new System.Drawing.Point(418, 387);
            this.Reportbutton.Name = "Reportbutton";
            this.Reportbutton.Size = new System.Drawing.Size(122, 48);
            this.Reportbutton.TabIndex = 10;
            this.Reportbutton.Text = "Reports";
            this.Reportbutton.UseVisualStyleBackColor = true;
            this.Reportbutton.Click += new System.EventHandler(this.Reportbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(212, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(358, 39);
            this.label1.TabIndex = 24;
            this.label1.Text = "Manager Dashboard";
            // 
            // ManagerFunction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Reportbutton);
            this.Controls.Add(this.updateItembutton);
            this.Controls.Add(this.ShowInventorybutton);
            this.Controls.Add(this.updateInventoryButton);
            this.Controls.Add(this.Logoutbutton);
            this.Controls.Add(this.DeleteItemButton);
            this.Controls.Add(this.AddItembutton);
            this.Controls.Add(this.DeleteCashierbutton);
            this.Controls.Add(this.AddCashierbutton);
            this.Controls.Add(this.DeleteCustomerbutton);
            this.Controls.Add(this.AddCustomerbutton);
            this.Name = "ManagerFunction";
            this.Text = "ManagerFunction";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddCustomerbutton;
        private System.Windows.Forms.Button DeleteCustomerbutton;
        private System.Windows.Forms.Button AddCashierbutton;
        private System.Windows.Forms.Button DeleteCashierbutton;
        private System.Windows.Forms.Button AddItembutton;
        private System.Windows.Forms.Button DeleteItemButton;
        private System.Windows.Forms.Button Logoutbutton;
        private System.Windows.Forms.Button updateInventoryButton;
        private System.Windows.Forms.Button ShowInventorybutton;
        private System.Windows.Forms.Button updateItembutton;
        private System.Windows.Forms.Button Reportbutton;
        private System.Windows.Forms.Label label1;
    }
}
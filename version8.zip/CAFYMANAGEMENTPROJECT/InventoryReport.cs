﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class InventoryReport : Form
    {
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");

        public InventoryReport()
        {
            InitializeComponent();
            DisplayInventory();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DisplayInventory()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
     
                    string query = "SELECT Item.ItemID, Item.ItemName, Item.ItemCategory, Item.ItemPrice, SUM(Inventory.Qty) AS TotalQuantity  FROM Item JOIN Inventory ON Item.ItemID = Inventory.ItemID "
                        +"GROUP BY Item.ItemID, Item.ItemName, Item.ItemCategory, Item.ItemPrice  ORDER BY Item.ItemCategory";


                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {

            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }
}


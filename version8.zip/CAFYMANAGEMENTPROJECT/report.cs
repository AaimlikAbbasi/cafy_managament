﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class report : Form
    {
        //private const string connectionString = "Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True";
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        public report()
        {
            InitializeComponent();
            /// Populate the ComboBox with available queries
            comboBox1.Items.Add("Retrieve all orders along with their items and customer details");
            comboBox1.Items.Add("Retrieve the total amount spent by each customer");
            comboBox1.Items.Add("Retrieve feedback details along with customer and order information");
            comboBox1.Items.Add("Retrieve the most expensive item in each order");
            comboBox1.Items.Add("Retrieve the Items sold most by each Cashier with Item Name");
            comboBox1.Items.Add("Ranking of each cashier by total sales");
            comboBox1.Items.Add("All the Cashiers of the cafe");
            comboBox1.Items.Add("All the Managers of the cafe");
            comboBox1.Items.Add("Total sales done by the cafe");
            comboBox1.Items.Add("Total Sales per Item Category");
            comboBox1.Items.Add("Total Items Sold per Customer");
            comboBox1.Items.Add("Retrieve Items with Low Inventory(Quantity Less Than 80)");
            comboBox1.Items.Add("Retrieve Customers with the Highest Loyalty Points");
            comboBox1.Items.Add("Retrieve Customers Who Placed Orders");
            comboBox1.Items.Add("Retrieve Cashiers with the Most Orders");
            comboBox1.Items.Add("Retrieve Items Sold to Customers"); 
            comboBox1.Items.Add("Top Selling Item Category");
        }
        private void ExecuteQuery(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            // Fill the DataGridView with the query results
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;

            // Execute the selected query
            switch (comboBox1.SelectedItem.ToString())
            {
                case "Retrieve all orders along with their items and customer details"://three joins
                   // ExecuteQuery("SELECT o.order_id, o.customerid, c.customerUsername, c.customerName, c.LoyaltyPts, o.cashierid, o.paymentmethod, o.Total, oi.itemid, i.ItemName, i.ItemCategory, i.ItemPrice FROM Orders o JOIN Customer c ON o.customerid = c.CustomerId JOIN OrderedItems oi ON o.order_id = oi.orderid JOIN Item i ON oi.itemid = i.ItemID");
                    ExecuteQuery("SELECT o.order_id, o.customerid, c.customerUsername, c.customerName, c.LoyaltyPts, o.cashierid, p.MethodName, o.Total, oi.itemid, i.ItemName, i.ItemCategory, i.ItemPrice FROM Orders o JOIN Customer c ON o.customerid = c.CustomerId JOIN OrderedItems oi ON o.order_id = oi.orderid JOIN Item i ON oi.itemid = i.ItemID Join Payment p on p.PaymentId = o.paymentmethod ");
                    break;

                case "Retrieve the total amount spent by each customer"://group by
                    ExecuteQuery("SELECT c.customerid, c.customerName, SUM(o.Total) AS TotalSpent FROM Customer c LEFT JOIN Orders o ON c.customerid = o.customerid GROUP BY c.customerid, c.customerName");
                    break;

                case "Retrieve feedback details along with customer and order information"://two joins
                    ExecuteQuery("SELECT cf.feedback_id, cf.customerID, c.customerName, cf.order_ID, o.Total, f.descriptionn, f.rating FROM CustomerFeedback cf JOIN Customer c ON cf.customerID = c.CustomerId JOIN Orders o ON cf.order_ID = o.order_id JOIN Feedback f ON cf.feedback_id = f.feedbackId");
                    break;

                case "Retrieve the most expensive item in each order"://group by
                    ExecuteQuery("SELECT o.order_id, MAX(i.ItemPrice) AS MostExpensiveItemPrice FROM Orders o JOIN OrderedItems oi ON o.order_id = oi.orderid JOIN Item i ON oi.itemid = i.ItemID GROUP BY o.order_id");
                  //  ExecuteQuery("SELECT o.order_id, c.customerName, i.ItemName, MAX(i.ItemPrice) AS MostExpensiveItemPrice " +
                      //           "FROM Orders o JOIN OrderedItems oi ON o.order_id = oi.orderid JOIN Item i ON oi.itemid = i.ItemID " +
                       //          "JOIN Customer c ON o.customerid = c.CustomerId GROUP BY o.order_id, c.customerName, i.ItemName");
                    break;

                case "Ranking of each cashier by total sales": //group by
                    ExecuteQuery("SELECT c.CashierID, c.cashierUsername, c.CashierName, SUM(o.Total) AS TotalSales FROM Cashier c"+
                                 " JOIN Orders o ON c.CashierID = o.cashierid GROUP BY c.CashierID, c.cashierUsername, c.CashierName ORDER BY TotalSales DESC");
                    break;

                case "All the Cashiers of the cafe":
                    ExecuteQuery(" SELECT CashierID, cashierUsername, CashierName, NULL AS phone FROM Cashier");
                    break;
                case "All the Managers of the cafe":
                    ExecuteQuery(" SELECT ManagerID, managerUsername, Name, phone FROM Manager");
                    break;
                case "Retrieve the Items sold most by each Cashier with Item Name":  //three joins
                    //ExecuteQuery("SELECT c.cashierUsername, i.ItemName, COUNT(*) AS SoldCount FROM Cashier c "+
                    //             "JOIN Orders o ON c.CashierID = o.cashierid JOIN OrderedItems oi ON o.order_id = oi.orderid"+
                    //             "JOIN Item i ON oi.itemid = i.ItemID GROUP BY c.cashierUsername, i.ItemName ORDER BY c.cashierUsername, SoldCount DESC");
                   
                     ExecuteQuery("SELECT c.cashierUsername, i.ItemName, COUNT(*) AS SoldCount " +
                      "FROM Cashier c " +
                       "JOIN Orders o ON c.CashierID = o.cashierid " +
                       "JOIN OrderedItems oi ON o.order_id = oi.orderid " +
                       "JOIN Item i ON oi.itemid = i.ItemID " +
                      "GROUP BY c.cashierUsername, i.ItemName " +
                       "ORDER BY c.cashierUsername, SoldCount DESC");
                    break;
                case "Total Sales per Item Category":   //two joins
                    ExecuteQuery("SELECT i.ItemCategory, SUM(o.Total) AS TotalSale " +
                                 "FROM Item i " +
                                 "JOIN OrderedItems oi ON i.ItemID = oi.itemid " +
                                 "JOIN Orders o ON oi.orderid = o.order_id " +
                                 "GROUP BY i.ItemCategory;");
                    break;

                case "Total Items Sold per Customer":///// two table join
                    ExecuteQuery("SELECT c.customerUsername, COUNT(oi.itemid) AS TotalItemsSold " +
                                 "FROM Customer c " +
                                 "JOIN Orders o ON c.CustomerId = o.customerid " +
                                 "JOIN OrderedItems oi ON o.order_id = oi.orderid " +
                                 "GROUP BY c.customerUsername;");
                    break;

                case "Retrieve Items with Low Inventory(Quantity Less Than 80)"://subqueryone
                    ExecuteQuery(
                        "SELECT i.ItemName, i.ItemCategory, inv.Qty " +
                        "FROM Item i " +
                        "LEFT JOIN Inventory inv ON i.ItemID = inv.Itemid " +
                        "WHERE inv.Qty < 80 " +
                        "   OR (inv.Qty IS NULL AND NOT EXISTS (" +
                        "       SELECT 1 " +
                        "       FROM Inventory subinv " +
                        "       WHERE subinv.Itemid = i.ItemID " +
                        "   ));"
                    );
                    break;

                case "Retrieve Customers with the Highest Loyalty Points"://nested subqueries
                    ExecuteQuery(
                        "SELECT c.customerName, c.customerUsername, c.LoyaltyPts " +
                        "FROM Customer c " +
                        "WHERE c.LoyaltyPts = (SELECT MAX(LoyaltyPts) FROM Customer);"
                    );
                    break;

                case "Retrieve Customers Who Placed Orders":      ////nested subquery
                    ExecuteQuery(
                        "SELECT customerName, customerUsername " +
                        "FROM Customer " +
                        "WHERE CustomerId IN ( " +
                        "    SELECT DISTINCT customerid " +
                        "    FROM Orders " +
                        ");"
                    );
                    break;
                         case "Retrieve Cashiers with the Most Orders":    ///nested sub quries
                    ExecuteQuery(
                        "SELECT cashierName, cashierUsername " +
                        "FROM Cashier " +
                        "WHERE CashierID = ( " +
                        "    SELECT TOP 1 cashierid " +
                        "    FROM Orders " +
                        "    GROUP BY cashierid " +
                        "    ORDER BY COUNT(order_id) DESC " +
                        ");"
                    );
                    break;
                       case "Retrieve Items Sold to Customers": ///three table join
                    ExecuteQuery("SELECT c.customerName, i.ItemName " +
                                 "FROM Customer c " +
                                 "JOIN Orders o ON c.CustomerId = o.customerid " +
                                 "JOIN OrderedItems oi ON o.order_id = oi.orderid " +
                                 "JOIN Item i ON oi.itemid = i.ItemID;");
                    break;

                case "Top Selling Item Category"://group by clause
               
                    ExecuteQuery("SELECT TOP 1 i.ItemCategory, COUNT(oi.itemid) AS ItemsSold FROM Item i JOIN OrderedItems oi ON i.ItemID = oi.itemid GROUP BY i.ItemCategory ORDER BY ItemsSold DESC;");
                    break;
                default:
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ManagerFunction form1 = new ManagerFunction();
            form1.Show();
            this.Hide();
        }
    }
}

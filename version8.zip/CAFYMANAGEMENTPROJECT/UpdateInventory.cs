﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class UpdateInventory : Form
    {
        private const string connectionString = "Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True";

        public UpdateInventory()
        {
            InitializeComponent();
            PopulateComboBox();
            
            CategorycomboBox.SelectedIndexChanged += CategorycomboBox_SelectedIndexChanged;
           // UpdateQuantityButton.Click += UpdateQuantityButton_Click;

        }

        private void PopulateComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                    connection.Open();

                    string query = "SELECT DISTINCT ItemCategory FROM Item";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CategorycomboBox.Items.Add(reader["ItemCategory"].ToString());
                            }
                        }
                    }
            }
            
           
        }

        private void CategorycomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear existing items in NamecomboBox
            NamecomboBox.Items.Clear();

            // Get the selected category
            string selectedCategory = CategorycomboBox.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedCategory))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                    connection.Open();

                    // Nested query to get names based on the selected category
                    string nameQuery = $"SELECT ItemName FROM Item WHERE ItemCategory = '{selectedCategory}'";

                     using (SqlCommand nameCommand = new SqlCommand(nameQuery, connection))
                     {
                         using (SqlDataReader nameReader = nameCommand.ExecuteReader())
                         {
                             while (nameReader.Read())
                             {
                                    NamecomboBox.Items.Add(nameReader["ItemName"].ToString());
                             }
                         }
                     }
                }
            }
        }

        private void UpdateQuantityButton_Click(object sender, EventArgs e)
        {
            // Get the selected category and name
            string selectedCategory = CategorycomboBox.SelectedItem?.ToString();
            string selectedName = NamecomboBox.SelectedItem?.ToString();

            // Check if both category and name are selected
            if (string.IsNullOrEmpty(selectedCategory) || string.IsNullOrEmpty(selectedName))
            {
                MessageBox.Show("Please select both category and name.");
                return;
            }

            // Parse the quantity from the text box
            if (!int.TryParse(QtytextBox.Text, out int additionalQuantity))
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Update the Inventory table by adding the additional quantity
                    string updateQuery = $"UPDATE Inventory " +
                                         $"SET Qty = Qty + {additionalQuantity} " +
                                         $"WHERE Itemid IN (SELECT ItemID FROM Item WHERE ItemCategory = '{selectedCategory}' AND ItemName = '{selectedName}')";

                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Quantity updated successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to update quantity.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating quantity: {ex.Message}");
            }
        }

        private void UpdateInventory_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {

            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CAFYMANAGEMENTPROJECT
{
    
    public partial class Menu : Form
    {
        

        private DataGridView dataGridViewMenu;
        // private const string ConnectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafy_management;Integrated Security=True"); // Replace with your SQL Server connection string
       // private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
       private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        public Menu()
        {
            InitializeComponent();
            PopulateComboBox();
        }
        private void PopulateComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT DISTINCT ItemCategory FROM Item";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            MenucomboBox.Items.Add(reader["ItemCategory"].ToString());
                        }
                    }
                }
            }
        }
        private void InitializePanel()
        {
        }

        private void InitializeDataGridView()
        {
            // Customize the appearance of the DataGridView
           
        }
        private void LoadMenuData()
        {
            
        }


        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void MenucomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = MenucomboBox.SelectedItem.ToString();
            DisplayMenu(selectedCategory);
        }
        private void DisplayMenu(string category)
        {
            panel1.Controls.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT ItemName, ItemPrice FROM Item WHERE ItemCategory = @Category";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Category", category);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        int y = 10; // Initial Y position for menu items
                        while (reader.Read())
                        {
                            Label itemNameLabel = new Label
                            {
                                Text = reader["ItemName"].ToString(),
                                Location = new Point(10, y),
                                AutoSize = true
                            };

                            Label priceLabel = new Label
                            {
                                Text = "$" + reader["ItemPrice"].ToString(),
                                Location = new Point(110, y),
                                AutoSize = true
                            };

                            panel1.Controls.Add(itemNameLabel);
                            panel1.Controls.Add(priceLabel);

                            y += 30; // Adjust the Y position for the next menu item
                        }
                    }
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void Orderbutton_Click(object sender, EventArgs e)
        {
            LoginSelection l = new LoginSelection();
            l.Visible = true;
            this.Visible = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class CustomerLogin : Form
    {
        public CustomerLogin()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafy_management;Integrated Security=True"); // Replace with your SQL Server connection string
        //private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
         private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            string customerName = textBox1.Text;
            string password1 = textBox2.Text;

            if (string.IsNullOrWhiteSpace(customerName) || string.IsNullOrWhiteSpace(password1))
            {
                MessageBox.Show("Please enter both customer name and password.");
                return;
            }

            try
            {
                
                int customerId = CheckCustomerLogin(customerName, password1);

                if (customerId > 0)
                {
                    MessageBox.Show("Login successful!");
                 
                    placeorder form9 = new placeorder(customerId);
                    form9.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid customer name or password.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private int CheckCustomerLogin(string customerName, string password1)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT CustomerId FROM Customer WHERE customerUsername= @CustomerName AND customerPassword = @Password";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerName", customerName);
                    command.Parameters.AddWithValue("@Password", password1);

                    object result = command.ExecuteScalar();

                    // If result is not null, return the customer ID
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void sign_up_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();

            // Show Form2
            form8.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
             
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

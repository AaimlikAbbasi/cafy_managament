﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class paymethod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.orderid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerid1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cashierid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentmethod1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.methodname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Display = new System.Windows.Forms.Button();
            this.addtoorder = new System.Windows.Forms.Button();
            this.paymentmethod = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Feedback = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(36, 86);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(169, 31);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "PAYMENT";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Display);
            this.panel1.Controls.Add(this.addtoorder);
            this.panel1.Controls.Add(this.paymentmethod);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Location = new System.Drawing.Point(155, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1108, 591);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.BurlyWood;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderid,
            this.customerid1,
            this.customername,
            this.cashierid,
            this.paymentmethod1,
            this.methodname,
            this.total});
            this.dataGridView1.Location = new System.Drawing.Point(20, 392);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1085, 183);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // orderid
            // 
            this.orderid.HeaderText = "Orderid";
            this.orderid.MinimumWidth = 8;
            this.orderid.Name = "orderid";
            this.orderid.Width = 150;
            // 
            // customerid1
            // 
            this.customerid1.HeaderText = "customerid";
            this.customerid1.MinimumWidth = 8;
            this.customerid1.Name = "customerid1";
            this.customerid1.Width = 150;
            // 
            // customername
            // 
            this.customername.HeaderText = "customername";
            this.customername.MinimumWidth = 8;
            this.customername.Name = "customername";
            this.customername.Width = 150;
            // 
            // cashierid
            // 
            this.cashierid.HeaderText = "cashierid";
            this.cashierid.MinimumWidth = 8;
            this.cashierid.Name = "cashierid";
            this.cashierid.Width = 150;
            // 
            // paymentmethod1
            // 
            this.paymentmethod1.HeaderText = "paymentmethod";
            this.paymentmethod1.MinimumWidth = 8;
            this.paymentmethod1.Name = "paymentmethod1";
            this.paymentmethod1.Width = 150;
            // 
            // methodname
            // 
            this.methodname.HeaderText = "methodname";
            this.methodname.MinimumWidth = 8;
            this.methodname.Name = "methodname";
            this.methodname.Width = 150;
            // 
            // total
            // 
            this.total.HeaderText = "total";
            this.total.MinimumWidth = 8;
            this.total.Name = "total";
            this.total.Width = 150;
            // 
            // Display
            // 
            this.Display.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Display.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Display.Location = new System.Drawing.Point(510, 305);
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(113, 38);
            this.Display.TabIndex = 6;
            this.Display.Text = "Display";
            this.Display.UseVisualStyleBackColor = true;
            this.Display.Click += new System.EventHandler(this.Display_Click);
            // 
            // addtoorder
            // 
            this.addtoorder.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addtoorder.ForeColor = System.Drawing.Color.BurlyWood;
            this.addtoorder.Location = new System.Drawing.Point(3, 201);
            this.addtoorder.Name = "addtoorder";
            this.addtoorder.Size = new System.Drawing.Size(202, 50);
            this.addtoorder.TabIndex = 4;
            this.addtoorder.Text = "ADD TO ORDER";
            this.addtoorder.UseVisualStyleBackColor = true;
            this.addtoorder.Click += new System.EventHandler(this.button1_Click);
            // 
            // paymentmethod
            // 
            this.paymentmethod.AutoSize = true;
            this.paymentmethod.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentmethod.Location = new System.Drawing.Point(561, 30);
            this.paymentmethod.Name = "paymentmethod";
            this.paymentmethod.Size = new System.Drawing.Size(217, 27);
            this.paymentmethod.TabIndex = 2;
            this.paymentmethod.Text = "Payment Method";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.BurlyWood;
            this.panel2.Location = new System.Drawing.Point(233, 86);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(813, 177);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Feedback
            // 
            this.Feedback.BackColor = System.Drawing.SystemColors.Control;
            this.Feedback.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feedback.ForeColor = System.Drawing.Color.BurlyWood;
            this.Feedback.Location = new System.Drawing.Point(12, 538);
            this.Feedback.Name = "Feedback";
            this.Feedback.Size = new System.Drawing.Size(119, 40);
            this.Feedback.TabIndex = 2;
            this.Feedback.Text = "feedback";
            this.Feedback.UseVisualStyleBackColor = false;
            this.Feedback.Click += new System.EventHandler(this.Feedback_Click);
            // 
            // paymethod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(1286, 627);
            this.Controls.Add(this.Feedback);
            this.Controls.Add(this.panel1);
            this.Name = "paymethod";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.form10_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label paymentmethod;
        private System.Windows.Forms.Button addtoorder;
        private System.Windows.Forms.Button Display;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderid;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn customername;
        private System.Windows.Forms.DataGridViewTextBoxColumn cashierid;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentmethod1;
        private System.Windows.Forms.DataGridViewTextBoxColumn methodname;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.Button Feedback;
    }
}
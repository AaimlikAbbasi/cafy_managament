﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class ItemDelete : Form
    {
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        public ItemDelete()
        {
            InitializeComponent();
        }

        private void Removebutton_Click(object sender, EventArgs e)
        {
            string itemname=textBox1.Text;
            if (string.IsNullOrEmpty(itemname))
            {
                MessageBox.Show("Cant be empty.");
                
            }

            try {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                };
            }
            catch { }
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {

            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }
}

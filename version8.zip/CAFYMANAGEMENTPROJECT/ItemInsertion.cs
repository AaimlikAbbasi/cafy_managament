﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class ItemInsertion : Form
    {
        public ItemInsertion()
        {
            InitializeComponent();
            PopulateComboBox();
        }
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");

        private void PopulateComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT DISTINCT ItemCategory FROM Item";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CategorycomboBox.Items.Add(reader["ItemCategory"].ToString());
                        }
                    }
                }
            }
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {
            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }

        private void Insertbutton_Click(object sender, EventArgs e)
        {
            string itemName = textBox1.Text;
            string category = CategorycomboBox.Text;
            string itemPriceText = textBox2.Text;

            // Validate input
            if (string.IsNullOrEmpty(itemName) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(itemPriceText))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (!int.TryParse(itemPriceText, out int itemPrice))
            {
                MessageBox.Show("Please enter correct Number.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Item WHERE ItemName = @ItemName";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@ItemName", itemName);

                        int existingItemCount = (int)checkCommand.ExecuteScalar();

                        if (existingItemCount > 0)
                        {
                            MessageBox.Show("Item with the same name already exists. Please choose a different ItemName.");
                            return;
                        }
                    }

                    string insertQuery = "INSERT INTO Item (ItemName, ItemCategory, ItemPrice) " +
                                         "VALUES (@ItemName, @Category, @ItemPrice)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ItemName", itemName);
                        command.Parameters.AddWithValue("@Category", category);
                        command.Parameters.AddWithValue("@ItemPrice", itemPrice);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Item inserted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to insert item.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void ItemInsertion_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

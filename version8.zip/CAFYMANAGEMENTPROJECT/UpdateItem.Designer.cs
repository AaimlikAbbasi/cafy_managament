﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class UpdateItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpdateButton = new System.Windows.Forms.Button();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CategorycomboBox = new System.Windows.Forms.ComboBox();
            this.NamecomboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ItemCategorylabel = new System.Windows.Forms.Label();
            this.ItemNameLabel = new System.Windows.Forms.Label();
            this.ItemCategoryBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PricetextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Dashboardbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UpdateButton
            // 
            this.UpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.UpdateButton.Location = new System.Drawing.Point(457, 302);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(105, 42);
            this.UpdateButton.TabIndex = 35;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(345, 181);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(217, 22);
            this.NametextBox.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "Item Name";
            // 
            // CategorycomboBox
            // 
            this.CategorycomboBox.FormattingEnabled = true;
            this.CategorycomboBox.Location = new System.Drawing.Point(345, 107);
            this.CategorycomboBox.Name = "CategorycomboBox";
            this.CategorycomboBox.Size = new System.Drawing.Size(217, 24);
            this.CategorycomboBox.TabIndex = 32;
            this.CategorycomboBox.UseWaitCursor = true;
            // 
            // NamecomboBox
            // 
            this.NamecomboBox.AllowDrop = true;
            this.NamecomboBox.FormattingEnabled = true;
            this.NamecomboBox.Location = new System.Drawing.Point(345, 143);
            this.NamecomboBox.Name = "NamecomboBox";
            this.NamecomboBox.Size = new System.Drawing.Size(217, 24);
            this.NamecomboBox.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 39);
            this.label1.TabIndex = 30;
            this.label1.Text = "Item Update";
            // 
            // ItemCategorylabel
            // 
            this.ItemCategorylabel.AutoSize = true;
            this.ItemCategorylabel.Location = new System.Drawing.Point(175, 115);
            this.ItemCategorylabel.Name = "ItemCategorylabel";
            this.ItemCategorylabel.Size = new System.Drawing.Size(90, 16);
            this.ItemCategorylabel.TabIndex = 29;
            this.ItemCategorylabel.Text = "Item Category";
            // 
            // ItemNameLabel
            // 
            this.ItemNameLabel.AutoSize = true;
            this.ItemNameLabel.Location = new System.Drawing.Point(175, 143);
            this.ItemNameLabel.Name = "ItemNameLabel";
            this.ItemNameLabel.Size = new System.Drawing.Size(72, 16);
            this.ItemNameLabel.TabIndex = 28;
            this.ItemNameLabel.Text = "Item Name";
            // 
            // ItemCategoryBox
            // 
            this.ItemCategoryBox.Location = new System.Drawing.Point(345, 221);
            this.ItemCategoryBox.Name = "ItemCategoryBox";
            this.ItemCategoryBox.Size = new System.Drawing.Size(217, 22);
            this.ItemCategoryBox.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(175, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 16);
            this.label3.TabIndex = 36;
            this.label3.Text = "Item Category";
            // 
            // PricetextBox
            // 
            this.PricetextBox.Location = new System.Drawing.Point(345, 255);
            this.PricetextBox.Name = "PricetextBox";
            this.PricetextBox.Size = new System.Drawing.Size(217, 22);
            this.PricetextBox.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(175, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 38;
            this.label4.Text = "Item Price";
            // 
            // Dashboardbutton
            // 
            this.Dashboardbutton.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Dashboardbutton.FlatAppearance.BorderSize = 3;
            this.Dashboardbutton.Location = new System.Drawing.Point(644, 388);
            this.Dashboardbutton.Name = "Dashboardbutton";
            this.Dashboardbutton.Size = new System.Drawing.Size(104, 36);
            this.Dashboardbutton.TabIndex = 40;
            this.Dashboardbutton.Text = "Dashboard";
            this.Dashboardbutton.UseVisualStyleBackColor = true;
            this.Dashboardbutton.Click += new System.EventHandler(this.Dashboardbutton_Click);
            // 
            // UpdateItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Dashboardbutton);
            this.Controls.Add(this.PricetextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ItemCategoryBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.NametextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CategorycomboBox);
            this.Controls.Add(this.NamecomboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ItemCategorylabel);
            this.Controls.Add(this.ItemNameLabel);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "UpdateItem";
            this.Text = "UpdateItem";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CategorycomboBox;
        private System.Windows.Forms.ComboBox NamecomboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ItemCategorylabel;
        private System.Windows.Forms.Label ItemNameLabel;
        private System.Windows.Forms.TextBox ItemCategoryBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PricetextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Dashboardbutton;
    }
}
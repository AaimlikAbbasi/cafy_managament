﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class CashierInsert : Form
    {
        public CashierInsert()
        {
            InitializeComponent();
        }
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");

        private void Insertbutton_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox3.Text;
            string name = textBox2.Text;

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(name))
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        // Replace "YourCashierTable" with the actual name of your Cashier table
                        string query = "INSERT INTO Cashier (cashierUsername, cashierPassword, CashierName) " +
                                       "VALUES (@Username, @Password, @Name)";

                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                            // Use parameters to prevent SQL injection
                            command.Parameters.AddWithValue("@Username", username);
                            command.Parameters.AddWithValue("@Password", password);
                            command.Parameters.AddWithValue("@Name", name);

                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Cashier data inserted successfully.");
                            }
                            else
                            {
                                MessageBox.Show("Failed to insert cashier data.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }
        }


        private void Dashboardbutton_Click(object sender, EventArgs e)
        {
            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }

        private void CashierInsert_Load(object sender, EventArgs e)
        {

        }



        //private void CashierInsert_Load(object sender, EventArgs e)
        //{

        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class LoginSelection : Form
    {
        public LoginSelection()
        {
            InitializeComponent();
        }

        private void CUSTOMER_LOGIN_Click(object sender, EventArgs e)
        {
            CustomerLogin form3 = new CustomerLogin();

            // Show Form2
            form3.Show();
            this.Hide();
        }

        private void MANAGER_LOGIN_Click(object sender, EventArgs e)
        {
            ManagerLogin form6 = new ManagerLogin();

            // Show Form2
            form6.Show();
            this.Hide();
        }

        private void CASHIER_LOGIN_Click(object sender, EventArgs e)
        {
            CashierLogin form7 = new CashierLogin();

            // Show Form2
            form7.Show();
            this.Hide();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}

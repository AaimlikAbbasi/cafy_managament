﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class ManagerLogin : Form
    {
        public ManagerLogin()
        {
            InitializeComponent();
        }
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void login_Click(object sender, EventArgs e)
        {
            string managerName = textBox1.Text;
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(managerName) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both manager username and password.");
                return;
            }

            try
            {
                
                if (CheckManagerLogin(managerName, password))
                {
                    MessageBox.Show("Login successful!");

                    ManagerFunction form1 = new ManagerFunction();

                    // Show Form2
                    form1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid manager name or password.");
                    ManagerLogin manager = new ManagerLogin();
                    this.Visible = false;
                    manager.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
       // private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True"); // Replace with your SQL Server connection string
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        private bool CheckManagerLogin(string managerName, string password2)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Manager WHERE managerUsername = @ManagerName AND managerPassword = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ManagerName", managerName);
                    command.Parameters.AddWithValue("@Password", password2);

                    int count = (int)command.ExecuteScalar();

                    return count > 0;
                }
            }
        }
    
        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

       

        private void PASSWORD_Click(object sender, EventArgs e)
        {

        }

        private void M_NAME_Click(object sender, EventArgs e)
        {

        }
    }
}
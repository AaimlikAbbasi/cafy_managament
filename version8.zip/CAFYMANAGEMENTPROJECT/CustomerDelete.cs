﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class CustomerDelete : Form
    {
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        public CustomerDelete()
        {
            InitializeComponent();
        }

        private void DeleteCustomerButton_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;

            // Ensure the username is provided
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please enter a username to delete.");
                return;
            }

            // Check if the username exists
            if (!IsUsernameExists(username))
            {
                MessageBox.Show("Username does not exist. Please enter a valid username.");
                return;
            }

            // Perform the database deletion
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Replace "YourCustomerTable" with the actual name of your Customer table
                    string query = "DELETE FROM Customer WHERE customerUsername = @Username";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Use parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@Username", username);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Customer deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete customer.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        // Function to check if the username exists
        private bool IsUsernameExists(string username)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Replace "YourCustomerTable" with the actual name of your Customer table
                string query = "SELECT COUNT(*) FROM Customer WHERE customerUsername = @Username";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    int count = (int)command.ExecuteScalar();

                    return count > 0;
                }
            }
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {
            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }
}

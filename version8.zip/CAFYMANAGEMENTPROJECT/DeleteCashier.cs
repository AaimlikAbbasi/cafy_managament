﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class DeleteCashier : Form
    {
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        public DeleteCashier()
        {
            InitializeComponent();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string usernameToDelete = textBox1.Text;

            if (string.IsNullOrEmpty(usernameToDelete))
            {
                MessageBox.Show("Please enter a username to delete.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "DELETE FROM Cashier WHERE cashierUsername = @Username";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {

                        command.Parameters.AddWithValue("@Username", usernameToDelete);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cashier deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete cashier. Make sure the username is correct.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {
            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }
}

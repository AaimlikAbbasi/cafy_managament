﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sign_up = new System.Windows.Forms.Label();
            this.customername = new System.Windows.Forms.Label();
            this.User_name = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.signup = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Sign_up
            // 
            this.Sign_up.AutoSize = true;
            this.Sign_up.Font = new System.Drawing.Font("Cooper Black", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sign_up.ForeColor = System.Drawing.Color.BurlyWood;
            this.Sign_up.Location = new System.Drawing.Point(141, 15);
            this.Sign_up.Name = "Sign_up";
            this.Sign_up.Size = new System.Drawing.Size(133, 31);
            this.Sign_up.TabIndex = 0;
            this.Sign_up.Text = "SIGN UP";
            // 
            // customername
            // 
            this.customername.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.customername.AllowDrop = true;
            this.customername.AutoSize = true;
            this.customername.BackColor = System.Drawing.SystemColors.Control;
            this.customername.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customername.ForeColor = System.Drawing.Color.BurlyWood;
            this.customername.Location = new System.Drawing.Point(72, 56);
            this.customername.Name = "customername";
            this.customername.Size = new System.Drawing.Size(68, 23);
            this.customername.TabIndex = 1;
            this.customername.Text = "Name";
            this.customername.Click += new System.EventHandler(this.USER_ID_Click);
            // 
            // User_name
            // 
            this.User_name.AutoSize = true;
            this.User_name.BackColor = System.Drawing.SystemColors.Control;
            this.User_name.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User_name.ForeColor = System.Drawing.Color.BurlyWood;
            this.User_name.Location = new System.Drawing.Point(72, 95);
            this.User_name.Name = "User_name";
            this.User_name.Size = new System.Drawing.Size(112, 23);
            this.User_name.TabIndex = 2;
            this.User_name.Text = "Username";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.SystemColors.Control;
            this.password.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.BurlyWood;
            this.password.Location = new System.Drawing.Point(72, 139);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(111, 23);
            this.password.TabIndex = 3;
            this.password.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(216, 58);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(175, 22);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(216, 97);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(175, 22);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(216, 139);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(175, 22);
            this.textBox3.TabIndex = 6;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // signup
            // 
            this.signup.BackColor = System.Drawing.Color.BurlyWood;
            this.signup.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup.ForeColor = System.Drawing.SystemColors.Control;
            this.signup.Location = new System.Drawing.Point(135, 179);
            this.signup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signup.Name = "signup";
            this.signup.Size = new System.Drawing.Size(122, 30);
            this.signup.TabIndex = 7;
            this.signup.Text = "Signup";
            this.signup.UseVisualStyleBackColor = false;
            this.signup.Click += new System.EventHandler(this.signup_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Sign_up);
            this.panel1.Controls.Add(this.signup);
            this.panel1.Controls.Add(this.customername);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.User_name);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.password);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(154, 65);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 235);
            this.panel1.TabIndex = 8;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form8";
            this.Text = "Form8";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Sign_up;
        private System.Windows.Forms.Label customername;
        private System.Windows.Forms.Label User_name;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button signup;
        private System.Windows.Forms.Panel panel1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class UpdateItem : Form
    {
        public UpdateItem()
        {
            InitializeComponent();
            CategorycomboBox.SelectedIndexChanged += SelectedIndexChanged;
            PopulateComboBox();
        }

        private const string connectionString = "Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True";

        private void PopulateComboBox()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string categoryQuery = "SELECT DISTINCT ItemCategory FROM Item";

                using (SqlCommand categoryCommand = new SqlCommand(categoryQuery, connection))
                {
                    using (SqlDataReader categoryReader = categoryCommand.ExecuteReader())
                    {
                        while (categoryReader.Read())
                        {
                            string category = categoryReader["ItemCategory"].ToString();
                            CategorycomboBox.Items.Add(category);
                        }
                    }
                }
            }
        }

        private void PopulateNameComboBox(string selectedCategory)
        {
            NamecomboBox.Items.Clear();

            if (!string.IsNullOrEmpty(selectedCategory))
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string nameQuery = "SELECT DISTINCT ItemName FROM Item WHERE ItemCategory = @Category";

                        using (SqlCommand nameCommand = new SqlCommand(nameQuery, connection))
                        {
                            nameCommand.Parameters.AddWithValue("@Category", selectedCategory);

                            using (SqlDataReader nameReader = nameCommand.ExecuteReader())
                            {
                                while (nameReader.Read())
                                {
                                    NamecomboBox.Items.Add(nameReader["ItemName"].ToString());
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = CategorycomboBox.SelectedItem?.ToString();
            PopulateNameComboBox(selectedCategory);
        }
        private void UpdateItemDetails()
        {
            string selectedCategory = CategorycomboBox.SelectedItem?.ToString();
            string selectedName = NamecomboBox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedCategory) || string.IsNullOrEmpty(selectedName))
            {
                MessageBox.Show("Please select both category and name.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE Item SET ";

                    if (!string.IsNullOrEmpty(ItemCategoryBox.Text))
                    {
                        updateQuery += $"ItemCategory = '{ItemCategoryBox.Text}', ";
                    }

                    if (!string.IsNullOrEmpty(NametextBox.Text))
                    {
                        updateQuery += $"ItemName = '{NametextBox.Text}', ";
                    }

                    if (!string.IsNullOrEmpty(PricetextBox.Text))

                    { 
                        if (decimal.TryParse(PricetextBox.Text, out decimal newPrice))
                        {
                            updateQuery += $"ItemPrice = {newPrice}, ";
                        }
                        else
                        {
                            MessageBox.Show("Please enter a valid price.");
                            return;
                        }
                    }

                    updateQuery = updateQuery.TrimEnd(' ', ',');

                    updateQuery += $" WHERE ItemCategory = '{selectedCategory}' AND ItemName = '{selectedName}'";

                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Item details updated successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Failed to update item details.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating item details: {ex.Message}");
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            UpdateItemDetails();
        }

        private void Dashboardbutton_Click(object sender, EventArgs e)
        {

            ManagerFunction page = new ManagerFunction();
            page.Visible = true;
            this.Visible = false;
        }
    }

}

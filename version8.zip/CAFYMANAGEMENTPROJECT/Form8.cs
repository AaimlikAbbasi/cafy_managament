﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
        // private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafy_management;Integrated Security=True"); // Replace with your SQL Server connection string
     //  private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");


        private void signup_Click(object sender, EventArgs e)
        {
            string customername = textBox1.Text;
            string Username = textBox2.Text;
            string password = textBox3.Text;

            // Check if either username or password is empty
            if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password cannot be empty. Please enter valid values.");
            }
            else
            {
                // Check if the username already exists
                if (CheckUsernameExists(Username))
                {
                    MessageBox.Show("Username already exists. Choose a different username.");
                }
                else
                {
                    // Username is unique, proceed with the signup process
                    int loyaltyPoints = 0; // You may set loyalty points to some default value

                    // Insert the new customer into the Customer table
                    if (AddCustomer(customername, Username, password, loyaltyPoints))
                    {
                        MessageBox.Show("Signup successful!");

                        // Additional actions after successful signup
                        CustomerLogin form9 = new CustomerLogin(); // Pass the customer name to Form9

                        // Show Form9 and hide the current form
                        form9.Show();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("Error occurred during signup. Please try again.");
                    }
                }
            }
        }



        private bool CheckUsernameExists(string username)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Customer WHERE customerUsername = @Username";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    // Instead of ExecuteScalar, use ExecuteReader to get a SqlDataReader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Check if there are any rows
                        if (reader.HasRows)
                        {
                            // Read the first row
                            reader.Read();

                            // Get the count from the first column
                            int count = reader.GetInt32(0);

                            // Close the reader
                            reader.Close();

                            // Return true if count is greater than 0
                            return count > 0;
                        }
                    }
                }
            }

            // Return false if there is an issue with the database or query
            return false;
        }

        private bool AddCustomer(string customerName, string customerUsername, string customerPassword, int loyaltyPoints)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Customer (customerName, customerUsername, customerPassword, LoyaltyPts) VALUES (@Name, @Username, @Password, @LoyaltyPts)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", customerName);
                    command.Parameters.AddWithValue("@Username", customerUsername);
                    command.Parameters.AddWithValue("@Password", customerPassword);
                    command.Parameters.AddWithValue("@LoyaltyPts", loyaltyPoints);

                    int rowsAffected = command.ExecuteNonQuery();

                    return rowsAffected > 0; // If rowsAffected is greater than 0, the insertion was successful
                }
            }
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void USER_ID_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

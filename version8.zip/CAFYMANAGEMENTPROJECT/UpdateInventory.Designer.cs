﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class UpdateInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NamecomboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ItemCategorylabel = new System.Windows.Forms.Label();
            this.ItemNameLabel = new System.Windows.Forms.Label();
            this.CategorycomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.QtytextBox = new System.Windows.Forms.TextBox();
            this.UpdateQuantityButton = new System.Windows.Forms.Button();
            this.Dashboardbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NamecomboBox
            // 
            this.NamecomboBox.AllowDrop = true;
            this.NamecomboBox.FormattingEnabled = true;
            this.NamecomboBox.Location = new System.Drawing.Point(356, 151);
            this.NamecomboBox.Name = "NamecomboBox";
            this.NamecomboBox.Size = new System.Drawing.Size(217, 24);
            this.NamecomboBox.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(344, 39);
            this.label1.TabIndex = 22;
            this.label1.Text = "Inverntory Update";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // ItemCategorylabel
            // 
            this.ItemCategorylabel.AutoSize = true;
            this.ItemCategorylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemCategorylabel.Location = new System.Drawing.Point(186, 123);
            this.ItemCategorylabel.Name = "ItemCategorylabel";
            this.ItemCategorylabel.Size = new System.Drawing.Size(108, 17);
            this.ItemCategorylabel.TabIndex = 20;
            this.ItemCategorylabel.Text = "Item Category";
            // 
            // ItemNameLabel
            // 
            this.ItemNameLabel.AutoSize = true;
            this.ItemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemNameLabel.Location = new System.Drawing.Point(186, 151);
            this.ItemNameLabel.Name = "ItemNameLabel";
            this.ItemNameLabel.Size = new System.Drawing.Size(84, 17);
            this.ItemNameLabel.TabIndex = 19;
            this.ItemNameLabel.Text = "Item Name";
            // 
            // CategorycomboBox
            // 
            this.CategorycomboBox.FormattingEnabled = true;
            this.CategorycomboBox.Location = new System.Drawing.Point(356, 115);
            this.CategorycomboBox.Name = "CategorycomboBox";
            this.CategorycomboBox.Size = new System.Drawing.Size(217, 24);
            this.CategorycomboBox.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(186, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 17);
            this.label2.TabIndex = 25;
            this.label2.Text = "Item Quantity";
            // 
            // QtytextBox
            // 
            this.QtytextBox.Location = new System.Drawing.Point(356, 189);
            this.QtytextBox.Name = "QtytextBox";
            this.QtytextBox.Size = new System.Drawing.Size(217, 22);
            this.QtytextBox.TabIndex = 26;
            // 
            // UpdateQuantityButton
            // 
            this.UpdateQuantityButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateQuantityButton.Location = new System.Drawing.Point(461, 270);
            this.UpdateQuantityButton.Name = "UpdateQuantityButton";
            this.UpdateQuantityButton.Size = new System.Drawing.Size(148, 42);
            this.UpdateQuantityButton.TabIndex = 27;
            this.UpdateQuantityButton.Text = "Add Quantity";
            this.UpdateQuantityButton.UseVisualStyleBackColor = true;
            this.UpdateQuantityButton.Click += new System.EventHandler(this.UpdateQuantityButton_Click);
            // 
            // Dashboardbutton
            // 
            this.Dashboardbutton.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Dashboardbutton.FlatAppearance.BorderSize = 3;
            this.Dashboardbutton.Location = new System.Drawing.Point(637, 375);
            this.Dashboardbutton.Name = "Dashboardbutton";
            this.Dashboardbutton.Size = new System.Drawing.Size(104, 36);
            this.Dashboardbutton.TabIndex = 41;
            this.Dashboardbutton.Text = "Dashboard";
            this.Dashboardbutton.UseVisualStyleBackColor = true;
            this.Dashboardbutton.Click += new System.EventHandler(this.Dashboardbutton_Click);
            // 
            // UpdateInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Dashboardbutton);
            this.Controls.Add(this.UpdateQuantityButton);
            this.Controls.Add(this.QtytextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CategorycomboBox);
            this.Controls.Add(this.NamecomboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ItemCategorylabel);
            this.Controls.Add(this.ItemNameLabel);
            this.Name = "UpdateInventory";
            this.Text = "UpdateInventory";
            this.Load += new System.EventHandler(this.UpdateInventory_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox NamecomboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ItemCategorylabel;
        private System.Windows.Forms.Label ItemNameLabel;
        private System.Windows.Forms.ComboBox CategorycomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox QtytextBox;
        private System.Windows.Forms.Button UpdateQuantityButton;
        private System.Windows.Forms.Button Dashboardbutton;
    }
}
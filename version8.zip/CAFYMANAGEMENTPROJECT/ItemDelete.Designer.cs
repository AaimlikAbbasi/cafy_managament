﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class ItemDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dashboardbutton = new System.Windows.Forms.Button();
            this.Removebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ItemNameLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Dashboardbutton
            // 
            this.Dashboardbutton.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Dashboardbutton.FlatAppearance.BorderSize = 3;
            this.Dashboardbutton.Location = new System.Drawing.Point(671, 390);
            this.Dashboardbutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Dashboardbutton.Name = "Dashboardbutton";
            this.Dashboardbutton.Size = new System.Drawing.Size(117, 45);
            this.Dashboardbutton.TabIndex = 26;
            this.Dashboardbutton.Text = "Dashboard";
            this.Dashboardbutton.UseVisualStyleBackColor = true;
            this.Dashboardbutton.Click += new System.EventHandler(this.Dashboardbutton_Click);
            // 
            // Removebutton
            // 
            this.Removebutton.ForeColor = System.Drawing.Color.BurlyWood;
            this.Removebutton.Location = new System.Drawing.Point(316, 150);
            this.Removebutton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Removebutton.Name = "Removebutton";
            this.Removebutton.Size = new System.Drawing.Size(84, 29);
            this.Removebutton.TabIndex = 25;
            this.Removebutton.Text = "Remove";
            this.Removebutton.UseVisualStyleBackColor = true;
            this.Removebutton.Click += new System.EventHandler(this.Removebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.BurlyWood;
            this.label1.Location = new System.Drawing.Point(25, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 46);
            this.label1.TabIndex = 24;
            this.label1.Text = "Remove Item";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(169, 45);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(244, 26);
            this.textBox1.TabIndex = 22;
            // 
            // ItemNameLabel
            // 
            this.ItemNameLabel.AutoSize = true;
            this.ItemNameLabel.ForeColor = System.Drawing.Color.BurlyWood;
            this.ItemNameLabel.Location = new System.Drawing.Point(26, 48);
            this.ItemNameLabel.Name = "ItemNameLabel";
            this.ItemNameLabel.Size = new System.Drawing.Size(87, 20);
            this.ItemNameLabel.TabIndex = 19;
            this.ItemNameLabel.Text = "Item Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ItemNameLabel);
            this.panel1.Controls.Add(this.Removebutton);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(158, 151);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(479, 206);
            this.panel1.TabIndex = 27;
            // 
            // ItemDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(824, 460);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Dashboardbutton);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ItemDelete";
            this.Text = "ItemDelete";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Dashboardbutton;
        private System.Windows.Forms.Button Removebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label ItemNameLabel;
        private System.Windows.Forms.Panel panel1;
    }
}
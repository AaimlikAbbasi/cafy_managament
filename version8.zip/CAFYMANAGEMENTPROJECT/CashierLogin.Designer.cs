﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class CashierLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CASHIER_LOGIN = new System.Windows.Forms.Label();
            this.USER_NAME = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.LOGIN = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CASHIER_LOGIN
            // 
            this.CASHIER_LOGIN.AutoSize = true;
            this.CASHIER_LOGIN.BackColor = System.Drawing.SystemColors.Control;
            this.CASHIER_LOGIN.Font = new System.Drawing.Font("Cooper Black", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CASHIER_LOGIN.ForeColor = System.Drawing.Color.BurlyWood;
            this.CASHIER_LOGIN.Location = new System.Drawing.Point(112, 21);
            this.CASHIER_LOGIN.Name = "CASHIER_LOGIN";
            this.CASHIER_LOGIN.Size = new System.Drawing.Size(246, 31);
            this.CASHIER_LOGIN.TabIndex = 0;
            this.CASHIER_LOGIN.Text = "CASHIER LOGIN";
            // 
            // USER_NAME
            // 
            this.USER_NAME.AutoSize = true;
            this.USER_NAME.BackColor = System.Drawing.SystemColors.Control;
            this.USER_NAME.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USER_NAME.ForeColor = System.Drawing.Color.BurlyWood;
            this.USER_NAME.Location = new System.Drawing.Point(53, 85);
            this.USER_NAME.Name = "USER_NAME";
            this.USER_NAME.Size = new System.Drawing.Size(112, 23);
            this.USER_NAME.TabIndex = 1;
            this.USER_NAME.Text = "Username";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.SystemColors.Control;
            this.password.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.BurlyWood;
            this.password.Location = new System.Drawing.Point(54, 142);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(111, 23);
            this.password.TabIndex = 2;
            this.password.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(194, 85);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(175, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(194, 142);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(175, 22);
            this.textBox2.TabIndex = 4;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // LOGIN
            // 
            this.LOGIN.BackColor = System.Drawing.Color.BurlyWood;
            this.LOGIN.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGIN.ForeColor = System.Drawing.SystemColors.Control;
            this.LOGIN.Location = new System.Drawing.Point(158, 198);
            this.LOGIN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LOGIN.Name = "LOGIN";
            this.LOGIN.Size = new System.Drawing.Size(99, 30);
            this.LOGIN.TabIndex = 5;
            this.LOGIN.Text = "Login";
            this.LOGIN.UseVisualStyleBackColor = false;
            this.LOGIN.Click += new System.EventHandler(this.LOGIN_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CASHIER_LOGIN);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.LOGIN);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.USER_NAME);
            this.panel1.Controls.Add(this.password);
            this.panel1.Location = new System.Drawing.Point(136, 78);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(440, 290);
            this.panel1.TabIndex = 6;
            // 
            // CashierLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(690, 420);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CashierLogin";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label CASHIER_LOGIN;
        private System.Windows.Forms.Label USER_NAME;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button LOGIN;
        private System.Windows.Forms.Panel panel1;
    }
}
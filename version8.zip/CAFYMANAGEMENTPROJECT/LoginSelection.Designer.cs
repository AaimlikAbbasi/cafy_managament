﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class LoginSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CUSTOMER_LOGIN = new System.Windows.Forms.Button();
            this.MANAGER_LOGIN = new System.Windows.Forms.Button();
            this.CASHIER_LOGIN = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CUSTOMER_LOGIN
            // 
            this.CUSTOMER_LOGIN.BackColor = System.Drawing.Color.BurlyWood;
            this.CUSTOMER_LOGIN.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CUSTOMER_LOGIN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CUSTOMER_LOGIN.Location = new System.Drawing.Point(59, 3);
            this.CUSTOMER_LOGIN.Name = "CUSTOMER_LOGIN";
            this.CUSTOMER_LOGIN.Size = new System.Drawing.Size(279, 63);
            this.CUSTOMER_LOGIN.TabIndex = 0;
            this.CUSTOMER_LOGIN.Text = "CUSTOMER_LOGIN";
            this.CUSTOMER_LOGIN.UseVisualStyleBackColor = false;
            this.CUSTOMER_LOGIN.Click += new System.EventHandler(this.CUSTOMER_LOGIN_Click);
            // 
            // MANAGER_LOGIN
            // 
            this.MANAGER_LOGIN.BackColor = System.Drawing.Color.BurlyWood;
            this.MANAGER_LOGIN.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MANAGER_LOGIN.ForeColor = System.Drawing.SystemColors.Control;
            this.MANAGER_LOGIN.Location = new System.Drawing.Point(59, 94);
            this.MANAGER_LOGIN.Name = "MANAGER_LOGIN";
            this.MANAGER_LOGIN.Size = new System.Drawing.Size(279, 61);
            this.MANAGER_LOGIN.TabIndex = 1;
            this.MANAGER_LOGIN.Text = "MANAGER_LOGIN";
            this.MANAGER_LOGIN.UseVisualStyleBackColor = false;
            this.MANAGER_LOGIN.Click += new System.EventHandler(this.MANAGER_LOGIN_Click);
            // 
            // CASHIER_LOGIN
            // 
            this.CASHIER_LOGIN.BackColor = System.Drawing.Color.BurlyWood;
            this.CASHIER_LOGIN.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CASHIER_LOGIN.ForeColor = System.Drawing.SystemColors.Control;
            this.CASHIER_LOGIN.Location = new System.Drawing.Point(59, 187);
            this.CASHIER_LOGIN.Name = "CASHIER_LOGIN";
            this.CASHIER_LOGIN.Size = new System.Drawing.Size(279, 65);
            this.CASHIER_LOGIN.TabIndex = 2;
            this.CASHIER_LOGIN.Text = "CASHIER_LOGIN";
            this.CASHIER_LOGIN.UseVisualStyleBackColor = false;
            this.CASHIER_LOGIN.Click += new System.EventHandler(this.CASHIER_LOGIN_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CUSTOMER_LOGIN);
            this.panel1.Controls.Add(this.CASHIER_LOGIN);
            this.panel1.Controls.Add(this.MANAGER_LOGIN);
            this.panel1.Location = new System.Drawing.Point(176, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 272);
            this.panel1.TabIndex = 3;
            // 
            // LoginSelection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(684, 471);
            this.Controls.Add(this.panel1);
            this.Name = "LoginSelection";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CUSTOMER_LOGIN;
        private System.Windows.Forms.Button MANAGER_LOGIN;
        private System.Windows.Forms.Button CASHIER_LOGIN;
        private System.Windows.Forms.Panel panel1;
    }
}
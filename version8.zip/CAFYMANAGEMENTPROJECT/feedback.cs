﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{

    
    public partial class feedback : Form
    {
        //SqlConnection connection = new SqlConnection("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        private int customerId; // Member variable to store customerId
        private int orderId; // Member variable to store orderId

        public feedback(int customerId, int orderId)
        {
            InitializeComponent();
            this.customerId = customerId; // Store the customerId passed from form10
            this.orderId = orderId; // Store the orderId passed from form10
            PopulateComboBox();
        }
        private void PopulateComboBox()
        {
            List<int> comboValues = new List<int> { 1, 2, 3, 4, 5 };

            comboBox1.DataSource = comboValues;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox2.Text = comboBox1.SelectedItem?.ToString();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Feedback: " + textBox1.Text);

        }

        private void submit_Click(object sender, EventArgs e)
        { 
            string feedbackDescription = textBox1.Text;

            int rating;
            if (int.TryParse(textBox2.Text, out rating))
            {
                InsertFeedback(rating, feedbackDescription);

                MessageBox.Show("Feedback submitted successfully!");
            }
            else
            {
                MessageBox.Show("Invalid rating. Please select a valid rating.");
            }
        }
        private void InsertFeedback(int rating, string description)
        {
            try
            {
                connection.Open();

                string feedbackQuery = "INSERT INTO Feedback (descriptionn, rating) OUTPUT INSERTED.feedbackId VALUES (@Description, @Rating)";
                using (SqlCommand feedbackCommand = new SqlCommand(feedbackQuery, connection))
                {
                    feedbackCommand.Parameters.AddWithValue("@Rating", rating);
                    feedbackCommand.Parameters.AddWithValue("@Description", description);

                    int feedbackId = (int)feedbackCommand.ExecuteScalar();

                    string customerFeedbackQuery = "INSERT INTO CustomerFeedback (customerID, feedback_id, order_ID) VALUES (@CustomerId, @FeedbackId, @OrderId)";
                    using (SqlCommand customerFeedbackCommand = new SqlCommand(customerFeedbackQuery, connection))
                    {
                        customerFeedbackCommand.Parameters.AddWithValue("@CustomerId", customerId);
                        customerFeedbackCommand.Parameters.AddWithValue("@FeedbackId", feedbackId);
                        customerFeedbackCommand.Parameters.AddWithValue("@OrderId", orderId);

                        customerFeedbackCommand.ExecuteNonQuery();
                    }

                    MessageBox.Show("Feedback submitted successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting feedback: " + ex.Message);
            }
            finally
            { 
                connection.Close();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void log_out_Click(object sender, EventArgs e)
        {
            HomeScreen form11 = new HomeScreen(); 
            form11.Show();
            this.Hide();
        }
    }
}

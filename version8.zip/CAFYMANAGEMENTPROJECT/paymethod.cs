﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class paymethod : Form
    {
        //private const string connectionString = ("Data Source=AAIMLIK\\SQLEXPRESS;Initial Catalog=cafyhammad;Integrated Security=True");
        private const string connectionString = ("Data Source=DESKTOP-2TLGV5P\\SQLEXPRESS;Initial Catalog=cafe;Integrated Security=True");
        private decimal totalAmount;
        private List<string> selectedItems;
        private int customerId;
        public paymethod(int customerId, decimal totalAmount, List<string> selectedItems)
        {
            InitializeComponent();

            
            this.customerId = customerId;
            this.totalAmount = totalAmount;
            this.selectedItems = selectedItems;

            PopulatePaymentMethods();
        }
       

        private void PopulatePaymentMethods()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT MethodName FROM Payment";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            List<string> paymentMethods = new List<string>();

                            while (reader.Read())
                            {
                                string methodName = reader["MethodName"].ToString();
                                paymentMethods.Add(methodName);
                            }

                            
                            comboBox1.DataSource = paymentMethods;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private int GetSelectedPaymentMethodId()
        {

            string selectedPaymentMethod = comboBox1.SelectedItem?.ToString();

            int paymentMethodId = -1; 

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT PaymentId FROM Payment WHERE MethodName = @MethodName";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MethodName", selectedPaymentMethod);

                        // Execute the query
                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            paymentMethodId = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            return paymentMethodId;
        }

        private void form10_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
            // You can perform additional tasks when the form loads
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            panel2.Controls.Clear();

            
            System.Windows.Forms.Label selectedPaymentLabel = new System.Windows.Forms.Label();
            selectedPaymentLabel.Text =  comboBox1.SelectedItem?.ToString();
            selectedPaymentLabel.AutoSize = true;
            selectedPaymentLabel.Location = new Point(10, 10); // Adjust the location as needed

            
            selectedPaymentLabel.Font = new Font("Arial", 8, FontStyle.Bold); // Example: Bold and size 14
            selectedPaymentLabel.ForeColor = Color.Black; // Example: Blue color

            panel2.Controls.Add(selectedPaymentLabel);
        }




        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                int paymentMethodId = GetSelectedPaymentMethodId();

                Random random = new Random();
                int cashierId = random.Next(1, 4); 

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            string insertOrderQuery = "INSERT INTO Orders (customerid, cashierid, paymentmethod, Total) OUTPUT INSERTED.order_id VALUES (@customerId, @cashierId, @paymentMethodId, @totalAmount)";

                            using (SqlCommand command = new SqlCommand(insertOrderQuery, connection, transaction))
                            {
                                command.Parameters.AddWithValue("@customerId", customerId);
                                command.Parameters.AddWithValue("@cashierId", cashierId);
                                command.Parameters.AddWithValue("@paymentMethodId", paymentMethodId);
                                command.Parameters.AddWithValue("@totalAmount", totalAmount);

                                
                                int orderId = Convert.ToInt32(command.ExecuteScalar());

                                foreach (string selectedItem in selectedItems)
                                {
                                    UpdateInventory(selectedItem, connection, transaction);

                                    InsertIntoOrderedItems(orderId, selectedItem, connection, transaction);
                                }

                                transaction.Commit();

                                MessageBox.Show("Order added successfully!");
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void InsertIntoOrderedItems(int orderId, string selectedItem, SqlConnection connection, SqlTransaction transaction)
        {
            try
            {
                int itemId = int.Parse(selectedItem);

                // Insert into OrderedItems table
                string insertOrderedItemsQuery = "INSERT INTO OrderedItems (orderid, itemid) VALUES (@orderId, @itemId)";

                using (SqlCommand insertCommand = new SqlCommand(insertOrderedItemsQuery, connection, transaction))
                {
                    insertCommand.Parameters.AddWithValue("@orderId", orderId);
                    insertCommand.Parameters.AddWithValue("@itemId", itemId);

                    insertCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error inserting into OrderedItems: {ex.Message}");
            }
        }
        private void UpdateInventory(string selectedItem, SqlConnection connection, SqlTransaction transaction)
        {
            try
            { 
                int itemId = int.Parse(selectedItem);

                // Decrease the quantity in the Inventory table
                string updateInventoryQuery = "UPDATE Inventory SET Qty = Qty - 1 WHERE Itemid = @itemId";

                using (SqlCommand updateCommand = new SqlCommand(updateInventoryQuery, connection, transaction))
                {
                    updateCommand.Parameters.AddWithValue("@itemId", itemId);

                    updateCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating inventory for item ID {selectedItem}: {ex.Message}");
            }
        }


        private void DisplayOrderDetails(int orderId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT o.order_id, o.customerid, c.customerName, o.cashierid, o.paymentmethod, p.MethodName, o.Total
                    FROM Orders o
                    INNER JOIN Customer c ON o.customerid = c.CustomerId
                    INNER JOIN Payment p ON o.paymentmethod = p.PaymentId
                    WHERE o.order_id = @orderId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@orderId", orderId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Populate the DataGridView directly
                                dataGridView1.Rows.Add(
                                    reader["order_id"],
                                    reader["customerid"],
                                    reader["customerName"],
                                    reader["cashierid"],
                                    reader["paymentmethod"],
                                    reader["MethodName"],
                                    reader["Total"]
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        private void Display_Click(object sender, EventArgs e)
        {
            try
            {
                int orderId = GetLatestOrderId();

                DisplayOrderDetails(orderId);
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private int GetLatestOrderId()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT TOP 1 order_id FROM Orders WHERE customerid = @customerId ORDER BY order_id DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@customerId", customerId);

                        // Execute the query
                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            return Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting latest order ID: " + ex.Message);
            }

            return -1; // Default value or error indicator
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Feedback_Click(object sender, EventArgs e)
        {
            int orderId = GetLatestOrderId();

            // Display order details in dataGridView1
           
            feedback form11 = new feedback(customerId, orderId); // Pass customerId to the constructor
            form11.Show();
            this.Hide();
        }

    }
}

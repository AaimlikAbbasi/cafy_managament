﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class ManagerLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.manager_login = new System.Windows.Forms.Label();
            this.M_NAME = new System.Windows.Forms.Label();
            this.PASSWORD = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // manager_login
            // 
            this.manager_login.AutoSize = true;
            this.manager_login.Font = new System.Drawing.Font("Cooper Black", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manager_login.ForeColor = System.Drawing.Color.BurlyWood;
            this.manager_login.Location = new System.Drawing.Point(64, 11);
            this.manager_login.Name = "manager_login";
            this.manager_login.Size = new System.Drawing.Size(236, 27);
            this.manager_login.TabIndex = 0;
            this.manager_login.Text = "MANAGER LOGIN";
            this.manager_login.Click += new System.EventHandler(this.label1_Click);
            // 
            // M_NAME
            // 
            this.M_NAME.AutoSize = true;
            this.M_NAME.BackColor = System.Drawing.SystemColors.Control;
            this.M_NAME.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M_NAME.ForeColor = System.Drawing.Color.BurlyWood;
            this.M_NAME.Location = new System.Drawing.Point(31, 75);
            this.M_NAME.Name = "M_NAME";
            this.M_NAME.Size = new System.Drawing.Size(112, 23);
            this.M_NAME.TabIndex = 1;
            this.M_NAME.Text = "Username";
            this.M_NAME.Click += new System.EventHandler(this.M_NAME_Click);
            // 
            // PASSWORD
            // 
            this.PASSWORD.AutoSize = true;
            this.PASSWORD.BackColor = System.Drawing.SystemColors.Control;
            this.PASSWORD.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PASSWORD.ForeColor = System.Drawing.Color.BurlyWood;
            this.PASSWORD.Location = new System.Drawing.Point(31, 122);
            this.PASSWORD.Name = "PASSWORD";
            this.PASSWORD.Size = new System.Drawing.Size(111, 23);
            this.PASSWORD.TabIndex = 2;
            this.PASSWORD.Text = "Password";
            this.PASSWORD.Click += new System.EventHandler(this.PASSWORD_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(180, 77);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(187, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(180, 122);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(187, 22);
            this.textBox2.TabIndex = 4;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.BurlyWood;
            this.login.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.login.Location = new System.Drawing.Point(145, 179);
            this.login.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(86, 34);
            this.login.TabIndex = 5;
            this.login.Text = "Login";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.manager_login);
            this.panel1.Controls.Add(this.login);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.PASSWORD);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.M_NAME);
            this.panel1.Location = new System.Drawing.Point(125, 62);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(383, 241);
            this.panel1.TabIndex = 6;
            // 
            // ManagerLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CAFYMANAGEMENTPROJECT.Properties.Resources._204639846_fillet_of_lamb_with_vegetables_and_spices_on_a_restaurant_table;
            this.ClientSize = new System.Drawing.Size(605, 355);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ManagerLogin";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label manager_login;
        private System.Windows.Forms.Label M_NAME;
        private System.Windows.Forms.Label PASSWORD;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.Panel panel1;
    }
}
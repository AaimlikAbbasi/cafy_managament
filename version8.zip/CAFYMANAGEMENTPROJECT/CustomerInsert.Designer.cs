﻿namespace CAFYMANAGEMENTPROJECT
{
    partial class CustomerInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CustomerPasswordLabel = new System.Windows.Forms.Label();
            this.CustomerNamelabel = new System.Windows.Forms.Label();
            this.CustomerUsernameLabel = new System.Windows.Forms.Label();
            this.CustomerInsertbutton = new System.Windows.Forms.Button();
            this.Dashboardbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(337, 44);
            this.label1.TabIndex = 13;
            this.label1.Text = "Customer Insertion";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(371, 215);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(217, 22);
            this.textBox3.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(371, 247);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(217, 22);
            this.textBox2.TabIndex = 11;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(371, 171);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(217, 22);
            this.textBox1.TabIndex = 10;
            // 
            // CustomerPasswordLabel
            // 
            this.CustomerPasswordLabel.AutoSize = true;
            this.CustomerPasswordLabel.Location = new System.Drawing.Point(199, 250);
            this.CustomerPasswordLabel.Name = "CustomerPasswordLabel";
            this.CustomerPasswordLabel.Size = new System.Drawing.Size(127, 16);
            this.CustomerPasswordLabel.TabIndex = 9;
            this.CustomerPasswordLabel.Text = "Customer Password";
            // 
            // CustomerNamelabel
            // 
            this.CustomerNamelabel.AutoSize = true;
            this.CustomerNamelabel.Location = new System.Drawing.Point(199, 215);
            this.CustomerNamelabel.Name = "CustomerNamelabel";
            this.CustomerNamelabel.Size = new System.Drawing.Size(104, 16);
            this.CustomerNamelabel.TabIndex = 8;
            this.CustomerNamelabel.Text = "Customer Name";
            // 
            // CustomerUsernameLabel
            // 
            this.CustomerUsernameLabel.AutoSize = true;
            this.CustomerUsernameLabel.Location = new System.Drawing.Point(199, 177);
            this.CustomerUsernameLabel.Name = "CustomerUsernameLabel";
            this.CustomerUsernameLabel.Size = new System.Drawing.Size(130, 16);
            this.CustomerUsernameLabel.TabIndex = 7;
            this.CustomerUsernameLabel.Text = "Customer Username";
            // 
            // CustomerInsertbutton
            // 
            this.CustomerInsertbutton.Location = new System.Drawing.Point(371, 308);
            this.CustomerInsertbutton.Name = "CustomerInsertbutton";
            this.CustomerInsertbutton.Size = new System.Drawing.Size(125, 37);
            this.CustomerInsertbutton.TabIndex = 14;
            this.CustomerInsertbutton.Text = "Add Customer";
            this.CustomerInsertbutton.UseVisualStyleBackColor = true;
            this.CustomerInsertbutton.Click += new System.EventHandler(this.CustomerInsertbutton_Click);
            // 
            // Dashboardbutton
            // 
            this.Dashboardbutton.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Dashboardbutton.FlatAppearance.BorderSize = 3;
            this.Dashboardbutton.Location = new System.Drawing.Point(662, 387);
            this.Dashboardbutton.Name = "Dashboardbutton";
            this.Dashboardbutton.Size = new System.Drawing.Size(104, 36);
            this.Dashboardbutton.TabIndex = 15;
            this.Dashboardbutton.Text = "Dashboard";
            this.Dashboardbutton.UseVisualStyleBackColor = true;
            this.Dashboardbutton.Click += new System.EventHandler(this.Dashboardbutton_Click);
            // 
            // CustomerInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Dashboardbutton);
            this.Controls.Add(this.CustomerInsertbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.CustomerPasswordLabel);
            this.Controls.Add(this.CustomerNamelabel);
            this.Controls.Add(this.CustomerUsernameLabel);
            this.Name = "CustomerInsert";
            this.Text = "CustomerInsert";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label CustomerPasswordLabel;
        private System.Windows.Forms.Label CustomerNamelabel;
        private System.Windows.Forms.Label CustomerUsernameLabel;
        private System.Windows.Forms.Button CustomerInsertbutton;
        private System.Windows.Forms.Button Dashboardbutton;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAFYMANAGEMENTPROJECT
{
    public partial class ManagerFunction : Form
    {
        public ManagerFunction()
        {
            InitializeComponent();
        }



        private void AddCustomerbutton_Click(object sender, EventArgs e)
        {
            CustomerInsert customer = new CustomerInsert();
            customer.Visible = true;
            this.Visible = false;

        }

        private void DeleteCustomerbutton_Click(object sender, EventArgs e)
        {
            CustomerDelete customer = new CustomerDelete();
            customer.Visible = true;
            this.Visible = false;
        }

        private void AddCashierbutton_Click(object sender, EventArgs e)
        {
            CashierInsert cashier = new CashierInsert();
            cashier.Visible = true;
            this.Visible = false;
        }

        private void DeleteCashierbutton_Click(object sender, EventArgs e)
        {
            DeleteCashier deleteCashier = new DeleteCashier();
            deleteCashier.Visible = true;
            this.Visible = false;
        }

        private void AddItembutton_Click(object sender, EventArgs e)
        {
            ItemInsertion itemInsertion = new ItemInsertion();
            itemInsertion.Visible = true;
            this.Visible = false;
        }

        private void DeleteItemButton_Click(object sender, EventArgs e)
        {
            ItemDelete itemDelete = new ItemDelete();
            itemDelete.Visible = true;
            this.Visible = false;
        }

        private void Logoutbutton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            if (result == DialogResult.Yes)
            {
                HomeScreen h = new HomeScreen();
                h.Visible = true;
                this.Visible = false;
            }
        }

        private void updateInventoryButton_Click(object sender, EventArgs e)
        {
            UpdateInventory inventory = new UpdateInventory();
            inventory.Visible = true;
            this.Visible = false;
        }

        private void ShowInventorybutton_Click(object sender, EventArgs e)
        {
            InventoryReport i = new InventoryReport();
            i.Visible = true;
            this.Visible = false;
        }

        private void Reportbutton_Click(object sender, EventArgs e)
        {
            
            report form1 = new report();

            // Show Form2
            form1.Show();
            this.Hide();
        }

        private void updateItembutton_Click(object sender, EventArgs e)
        {
            UpdateItem updateItem = new UpdateItem();
            updateItem.Visible = true;
            this.Visible = false;
        }
    }
}
